repo: germarino18/Automatizacion_con_Honeypots_Tesis
branch: main
path: web/src

## Last sync
date: 2026-09-06T00:15:00Z

### Updated in this project
- Nueva interfaz "Honeypot SOC" (5 pantallas) sobre el design system Nocturne.
- Estructura y nomenclatura tomadas de web/src (Resumen, Ataques en Vivo, MITRE, Malware/IoC).
- Sidebar con estado de servicios (API, Postgres, n8n, honeypots) replicado de Sidebar.tsx.

## Screen map
| Pantalla | Archivos del repo |
| --- | --- |
| Resumen | web/src/features/overview/Resumen.tsx, web/src/components/MetricCard.tsx |
| Ataques en Vivo | web/src/features/live-feed/AtaquesEnVivo.tsx, useLiveEvents.ts |
| Detalle de Incidente | web/src/features/events-explorer/EventDetailDrawer.tsx |
| Matriz MITRE ATT&CK | web/src/features/mitre/MatrizMitre.tsx, grouping.ts |
| Inteligencia / IoC | web/src/features/malware/MalwareIoc.tsx, iocFilters.ts |
| Shell / navegación | web/src/components/Sidebar.tsx, web/src/lib/useHealth.ts |
